import os
import sys

# Spark imports
from pyspark.rdd import RDD
from pyspark.sql import DataFrame
from pyspark.sql import SparkSession
from pyspark.sql.functions import desc

# Dask imports
# import dask.bag as db
import dask.dataframe as dd  # you can use Dask bags or dataframes
from csv import DictReader
from collections import Counter

"""
INTRODUCTION

The goal of this assignment is to implement a basic analysis of textual 
data using Apache Spark (http://spark.apache.org) and 
Dask (https://dask.org). 
"""

"""
DATASET

We will study a dataset provided by the city of Montreal that contains 
the list of trees treated against the emerald ash borer 
(https://en.wikipedia.org/wiki/Emerald_ash_borer). The dataset is 
described at 
http://donnees.ville.montreal.qc.ca/dataset/frenes-publics-proteges-injection-agrile-du-frene 
(use Google translate to translate from French to English). 

We will use the 2015 and 2016 data sets available in directory `data`.
"""

"""
HELPER FUNCTIONS

These functions are here to help you. Instructions will tell you when
you should use them. Don't modify them!
"""

# Initialize a spark session.
def init_spark():
    spark = (
        SparkSession.builder.appName("Python Spark SQL basic example")
        .config("spark.some.config.option", "some-value")
        .getOrCreate()
    )
    return spark


# Useful functions to print RDDs and Dataframes.
def toCSVLineRDD(rdd):
    """
    This function convert an RDD or a DataFrame into a CSV string
    """
    a = rdd.map(lambda row: ",".join([str(elt) for elt in row])).reduce(
        lambda x, y: os.linesep.join([x, y])
    )
    return a + os.linesep


def toCSVLine(data):
    """
    Convert an RDD or a DataFrame into a CSV string
    """
    if isinstance(data, RDD):
        return toCSVLineRDD(data)
    elif isinstance(data, DataFrame):
        return toCSVLineRDD(data.rdd)
    return None


"""
Plain PYTHON implementation

To get started smoothly and become familiar with the assignment's 
technical context (Git, GitHub, pytest, Travis), we will implement a 
few steps in plain Python.
"""

# Python answer functions
def count(filename):
    """
    Write a Python (not DataFrame, nor RDD) script that prints the number of trees (non-header lines) in
    the data file passed as first argument.
    Test file: tests/test_count.py
    Note: The return value should be an integer
    """

    with open(filename) as f:
        f.readline()
        return len(f.readlines())


def parks(filename):
    """
    Write a Python (not DataFrame, nor RDD) script that prints the number of trees that are *located in a park*.
    To get the park location information, have a look at the *Nom_parc* column (name of park).
    Test file: tests/test_parks.py
    Note: The return value should be an integer
    """

    with open(filename) as f:
        reader = DictReader(f)

        return sum([1 for row in reader if row["Nom_parc"] != ""])


def uniq_parks(filename):
    """
    Write a Python (not DataFrame, nor RDD) script that prints the list of unique parks where trees
    were treated. The list must be ordered alphabetically. Every element in the list must be printed on
    a new line.
    Test file: tests/test_uniq_parks.py
    Note: The return value should be a string with one park name per line
    """

    with open(filename) as f:
        reader = DictReader(f)

        return (
            os.linesep.join(
                sorted({row["Nom_parc"] for row in reader if row["Nom_parc"] != ""})
            )
            + os.linesep
        )


def uniq_parks_counts(filename):
    """
    Write a Python (not DataFrame, nor RDD) script that counts the number of trees treated in each park
    and prints a list of "park,count" pairs in a CSV manner ordered
    alphabetically by the park name. Every element in the list must be printed
    on a new line.
    Test file: tests/test_uniq_parks_counts.py
    Note: The return value should be a CSV string
          Have a look at the file *tests/list_parks_count.txt* to get the exact return format.
    """

    with open(filename) as f:
        reader = DictReader(f)

        parks = Counter([row["Nom_parc"] for row in reader if row["Nom_parc"] != ""])
        return (
            os.linesep.join(
                [
                    f"{park},{count}"
                    for park, count in sorted(parks.items(), key=lambda x: x[0])
                ]
            )
            + os.linesep
        )


def frequent_parks_count(filename):
    """
    Write a Python (not DataFrame, nor RDD) script that prints the list of the 10 parks with the
    highest number of treated trees. Parks must be ordered by decreasing
    number of treated trees and by alphabetical order when they have similar number.
    Every list element must be printed on a new line.
    Test file: tests/test_frequent_parks_count.py
    Note: The return value should be a CSV string.
          Have a look at the file *tests/frequent.txt* to get the exact return format.
    """
    with open(filename) as f:
        reader = DictReader(f)

        parks = Counter(
            [row["Nom_parc"] for row in reader if row["Nom_parc"] != ""]
        ).most_common(10)
        parks.sort(key=lambda x: (-x[1], x[0]))
        return (
            os.linesep.join([f"{park},{count}" for park, count in parks]) + os.linesep
        )


def intersection(filename1, filename2):
    """
    Write a Python (not DataFrame, nor RDD) script that prints the alphabetically sorted list of
    parks that had trees treated both in 2016 and 2015. Every list element
    must be printed on a new line.
    Test file: tests/test_intersection.py
    Note: The return value should be a CSV string.
          Have a look at the file *tests/intersection.txt* to get the exact return format.
    """

    def get_parks(fn):
        with open(fn) as f:
            reader = DictReader(f)
            parks = {row["Nom_parc"] for row in reader if row["Nom_parc"] != ""}
        return parks

    intersect = get_parks(filename1) & get_parks(filename2)

    return os.linesep.join(park for park in sorted(intersect)) + os.linesep


"""
SPARK RDD IMPLEMENTATION

You will now have to re-implement all the functions above using Apache 
Spark's Resilient Distributed Datasets API (RDD, see documentation at 
https://spark.apache.org/docs/latest/rdd-programming-guide.html). 
Outputs must be identical to the ones obtained above in plain Python. 
However, all operations must be re-implemented using the RDD API, you 
are not allowed to simply convert results obtained with plain Python to 
RDDs (this will be checked). Note that the function *toCSVLine* in the 
HELPER section at the top of this file converts RDDs into CSV strings.
"""

# RDD functions


def count_rdd(filename):
    """
    Write a Python script using RDDs that prints the number of trees
    (non-header lines) in the data file passed as first argument.
    Test file: tests/test_count_rdd.py
    Note: The return value should be an integer
    """

    spark = init_spark()
    return spark.read.csv(filename, header=True).rdd.count()


def parks_rdd(filename):
    """
    Write a Python script using RDDs that prints the number of trees that are *located in a park*.
    To get the park location information, have a look at the *Nom_parc* column (name of park).
    Test file: tests/test_parks_rdd.py
    Note: The return value should be an integer
    """

    spark = init_spark()
    return (
        spark.read.csv(filename, header=True)
        .rdd.map(lambda x: x["Nom_parc"])
        .filter(lambda x: x)
        .count()
    )


def uniq_parks_rdd(filename):
    """
    Write a Python script using RDDs that prints the list of unique parks where
    trees were treated. The list must be ordered alphabetically. Every element
    in the list must be printed on a new line.
    Test file: tests/test_uniq_parks_rdd.py
    Note: The return value should be a CSV string
    """

    spark = init_spark()

    return (
        spark.read.csv(filename, header=True)
        .rdd.map(lambda x: x["Nom_parc"])
        .distinct()
        .filter(lambda x: x)
        .sortBy(lambda x: x)
        .reduce(lambda x, y: os.linesep.join([x, y]))
        + os.linesep
    )


def uniq_parks_counts_rdd(filename):
    """
    Write a Python script using RDDs that counts the number of trees treated in
    each park and prints a list of "park,count" pairs in a CSV manner ordered
    alphabetically by the park name. Every element in the list must be printed
    on a new line.
    Test file: tests/test_uniq_parks_counts_rdd.py
    Note: The return value should be a CSV string
          Have a look at the file *tests/list_parks_count.txt* to get the exact return format.
    """

    spark = init_spark()

    def merge(x, y):
        if x is not None:
            return os.linesep.join([x, f"{y[0]},{y[1]}"])
        return f"{y[0]},{y[1]}"

    def merge_partitions(x, y):
        if x is not None:
            return os.linesep.join([x, y])
        return y

    return (
        spark.read.csv(filename, header=True)
        .rdd.map(lambda x: (x["Nom_parc"], 1))
        .filter(lambda x: x[0])
        .reduceByKey(lambda x, y: x + y)
        .sortBy(lambda x: x[0])
        .aggregate(None, merge, merge_partitions)
        + os.linesep
    )


def frequent_parks_count_rdd(filename):
    """
    Write a Python script using RDDs that prints the list of the 10 parks with
    the highest number of treated trees. Parks must be ordered by decreasing
    number of treated trees and by alphabetical order when they have similar
    number.  Every list element must be printed on a new line.
    Test file: tests/test_frequent_parks_count_rdd.py
    Note: The return value should be a CSV string.
          Have a look at the file *tests/frequent.txt* to get the exact return format.
    """

    spark = init_spark()

    parks = (
        spark.read.csv(filename, header=True)
        .rdd.map(lambda x: (x["Nom_parc"], 1))
        .filter(lambda x: x[0])
        .reduceByKey(lambda x, y: x + y)
        .takeOrdered(10, key=lambda x: (-x[1], x[0]))
    )

    return os.linesep.join([f"{p[0]},{p[1]}" for p in parks]) + os.linesep


def intersection_rdd(filename1, filename2):
    """
    Write a Python script using RDDs that prints the alphabetically sorted list
    of parks that had trees treated both in 2016 and 2015. Every list element
    must be printed on a new line.
    Test file: tests/test_intersection_rdd.py
    Note: The return value should be a CSV string.
          Have a look at the file *tests/intersection.txt* to get the exact return format.
    """

    spark = init_spark()

    def gen_rdd(filename):
        return (
            spark.read.csv(filename, header=True)
            .rdd.map(lambda x: x["Nom_parc"])
            .distinct()
            .filter(lambda x: x)
        )

    rdd1 = gen_rdd(filename1)
    rdd2 = gen_rdd(filename2)

    return (
        rdd1.intersection(rdd2)
        .sortBy(lambda x: x[0])
        .reduce(lambda x, y: os.linesep.join([x, y]))
        + os.linesep
    )


"""
SPARK DATAFRAME IMPLEMENTATION

You will now re-implement all the tasks above using Apache Spark's 
DataFrame API (see documentation at 
https://spark.apache.org/docs/latest/sql-programming-guide.html). 
Outputs must be identical to the ones obtained above in plain Python. 
Note: all operations must be re-implemented using the DataFrame API, 
you are not allowed to simply convert results obtained with the RDD API 
to Data Frames. Note that the function *toCSVLine* in the HELPER 
section at the top of this file also converts DataFrames into CSV 
strings.
"""

# DataFrame functions


def count_df(filename):
    """
    Write a Python script using DataFrames that prints the number of trees
    (non-header lines) in the data file passed as first argument.
    Test file: tests/test_count_df.py
    Note: The return value should be an integer
    """

    spark = init_spark()

    return spark.read.csv(filename, header=True).count()


def parks_df(filename):
    """
    Write a Python script using DataFrames that prints the number of trees that are *located in a park*.
    To get the park location information, have a look at the *Nom_parc* column (name of park).
    Test file: tests/test_parks_df.py
    Note: The return value should be an integer
    """

    spark = init_spark()

    return spark.read.csv(filename, header=True).select(["Nom_parc"]).dropna().count()


def uniq_parks_df(filename):
    """
    Write a Python script using DataFrames that prints the list of unique parks
    where trees were treated. The list must be ordered alphabetically. Every
    element in the list must be printed on a new line.
    Test file: tests/test_uniq_parks_df.py
    Note: The return value should be a CSV string
    """

    spark = init_spark()
    return (
        spark.read.csv(filename, header=True)
        .select("Nom_parc")
        .dropna()
        .drop_duplicates()
        .orderBy("Nom_parc")
        .rdd.map(lambda row: row["Nom_parc"])
        .reduce(lambda x, y: os.linesep.join([x, y]))
        + os.linesep
    )


def uniq_parks_counts_df(filename):
    """
    Write a Python script using DataFrames that counts the number of trees
    treated in each park and prints a list of "park,count" pairs in a CSV
    manner ordered alphabetically by the park name. Every element in the list
    must be printed on a new line.
    Test file: tests/test_uniq_parks_counts_df.py
    Note: The return value should be a CSV string
          Have a look at the file *tests/list_parks_count.txt* to get the exact return format.
    """

    def merge(x, y):
        if x is not None:
            return os.linesep.join([x, f"{y['Nom_parc']},{y['count']}"])
        return f"{y['Nom_parc']},{y['count']}"

    def merge_partitions(x, y):
        if x is not None:
            return os.linesep.join([x, y])
        return y

    spark = init_spark()
    return (
        spark.read.csv(filename, header=True)
        .select("Nom_parc")
        .dropna()
        .groupBy("Nom_parc")
        .count()
        .orderBy("Nom_parc")
        .rdd.aggregate(None, merge, merge_partitions)
        + os.linesep
    )


def frequent_parks_count_df(filename):
    """
    Write a Python script using DataFrames that prints the list of the 10 parks
    with the highest number of treated trees. Parks must be ordered by
    decreasing number of treated trees and by alphabetical order when they have
    similar number.  Every list element must be printed on a new line.
    Test file: tests/test_frequent_parks_count_df.py
    Note: The return value should be a CSV string.
          Have a look at the file *tests/frequent.txt* to get the exact return format.
    """

    spark = init_spark()

    def merge(x, y):
        if x is not None:
            return os.linesep.join([x, f"{y['Nom_parc']},{y['count']}"])
        return f"{y['Nom_parc']},{y['count']}"

    def merge_partitions(x, y):
        if x is not None:
            return os.linesep.join([x, y])
        return y

    spark = init_spark()
    return (
        spark.read.csv(filename, header=True)
        .select("Nom_parc")
        .dropna()
        .groupBy("Nom_parc")
        .count()
        .orderBy(["count", "Nom_parc"], ascending=[0, 1])
        .limit(10)
        .rdd.aggregate(None, merge, merge_partitions)
        + os.linesep
    )


def intersection_df(filename1, filename2):
    """
    Write a Python script using DataFrames that prints the alphabetically
    sorted list of parks that had trees treated both in 2016 and 2015. Every
    list element must be printed on a new line.
    Test file: tests/test_intersection_df.py
    Note: The return value should be a CSV string.
          Have a look at the file *tests/intersection.txt* to get the exact return format.
    """

    spark = init_spark()

    def gen_df(filename):
        return (
            spark.read.csv(filename, header=True)
            .select("Nom_parc")
            .dropna()
            .drop_duplicates()
        )

    df1 = gen_df(filename1)
    df2 = gen_df(filename2)

    return (
        df1.intersect(df2)
        .orderBy("Nom_parc")
        .rdd.map(lambda x: x["Nom_parc"])
        .reduce(lambda x, y: os.linesep.join([x, y]))
        + os.linesep
    )


"""
DASK IMPLEMENTATION (bonus)

You will now re-implement all the tasks above using Dask (see 
documentation at http://docs.dask.org/en/latest). Outputs must be 
identical to the ones obtained previously. Note: all operations must be 
re-implemented using Dask, you are not allowed to simply convert 
results obtained with the other APIs.
"""

# Dask functions


def count_dask(filename):
    """
    Write a Python script using Dask that prints the number of trees
    (non-header lines) in the data file passed as first argument.
    Test file: tests/test_count_dask.py
    Note: The return value should be an integer
    """

    # ADD YOUR CODE HERE
    df = dd.read_csv(filename, dtype={"Nom_parc": str})
    return len(df)


def parks_dask(filename):
    """
    Write a Python script using Dask that prints the number of trees that are *located in a park*.
    To get the park location information, have a look at the *Nom_parc* column (name of park).
    Test file: tests/test_parks_dask.py
    Note: The return value should be an integer
    """

    return len(dd.read_csv(filename, dtype={"Nom_parc": str})["Nom_parc"].dropna())


def uniq_parks_dask(filename):
    """
    Write a Python script using Dask that prints the list of unique parks
    where trees were treated. The list must be ordered alphabetically. Every
    element in the list must be printed on a new line.
    Test file: tests/test_uniq_parks_dask.py
    Note: The return value should be a CSV string
    """

    return "".join(
        dd.read_csv(filename, dtype={"Nom_parc": str})["Nom_parc"]
        .dropna()
        .drop_duplicates()
        .to_frame()
        .set_index("Nom_parc")
        .reset_index()["Nom_parc"]
        .apply(lambda row: row + os.linesep)
        .compute()
        .tolist()
    )


def uniq_parks_counts_dask(filename):
    """
    Write a Python script using Dask that counts the number of trees
    treated in each park and prints a list of "park,count" pairs in a CSV
    manner ordered alphabetically by the park name. Every element in the list
    must be printed on a new line.
    Test file: tests/test_uniq_parks_counts_dask.py
    Note: The return value should be a CSV string
          Have a look at the file *tests/list_parks_count.txt* to get the exact return format.
    """

    return "".join(
        dd.read_csv(filename, dtype={"Nom_parc": str})["Nom_parc"]
        .value_counts(dropna=True)
        .to_frame()
        .reset_index()
        .rename(columns={"Nom_parc": "count", "index": "Nom_parc"})
        .set_index("Nom_parc")
        .reset_index()
        .apply(lambda r: f"{r[0]},{r[1]}{os.linesep}", axis=1, meta=(str, int))
        .compute()
        .to_list()
    )


def frequent_parks_count_dask(filename):
    """
    Write a Python script using Dask that prints the list of the 10 parks
    with the highest number of treated trees. Parks must be ordered by
    decreasing number of treated trees and by alphabetical order when they have
    similar number.  Every list element must be printed on a new line.
    Test file: tests/test_frequent_parks_count_dask.py
    Note: The return value should be a CSV string.
          Have a look at the file *tests/frequent.txt* to get the exact return format.
    """

    return "".join(
        dd.read_csv(filename, dtype={"Nom_parc": str})["Nom_parc"]
        .value_counts(dropna=True)
        .to_frame()
        .reset_index()
        .rename(columns={"Nom_parc": "count", "index": "Nom_parc"})
        .nlargest(10, columns=["count"])
        .reset_index()
        .apply(lambda r: f"{r[1]},{r[2]}{os.linesep}", axis=1, meta=(str, int))
        .compute()
        .to_list()
    )


def intersection_dask(filename1, filename2):
    """
    Write a Python script using Dask that prints the alphabetically
    sorted list of parks that had trees treated both in 2016 and 2015. Every
    list element must be printed on a new line.
    Test file: tests/test_intersection_dask.py
    Note: The return value should be a CSV string.
          Have a look at the file *tests/intersection.txt* to get the exact return format.
    """

    def gen_df(filename):
        return (
            dd.read_csv(filename, dtype={"Nom_parc": str, "No_Civiq": str})["Nom_parc"]
            .dropna()
            .drop_duplicates()
            .to_frame()
        )

    df1 = gen_df(filename1)
    df2 = gen_df(filename2)

    return "".join(
        df1.merge(df2, on="Nom_parc")
        .apply(lambda r: r["Nom_parc"] + os.linesep, axis=1, meta=(str))
        .compute()
        .to_list()
    )
